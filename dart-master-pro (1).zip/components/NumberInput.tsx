
import React, { useState } from 'react';

interface NumberInputProps {
  onScore: (value: number, multiplier: number) => void;
}

const NumberInput: React.FC<NumberInputProps> = ({ onScore }) => {
  const [multiplier, setMultiplier] = useState<number>(1);
  const numbers = Array.from({ length: 20 }, (_, i) => i + 1);

  return (
    <div className="w-full max-w-sm flex flex-col gap-4 p-4 glass rounded-[2rem] border border-white/5 shadow-2xl">
      <div className="grid grid-cols-3 gap-2">
        {(['Single', 'Double', 'Triple'] as const).map((m, i) => (
          <button 
            key={m}
            onClick={() => setMultiplier(i + 1)}
            className={`py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${multiplier === i + 1 ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-900/50 text-slate-500 hover:text-slate-300'}`}
          >
            {m}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-2">
        {numbers.map(n => (
          <button 
            key={n}
            onClick={() => onScore(n, multiplier)}
            className="aspect-square flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-xl font-black text-xl text-white border border-white/5 transition-all active:scale-95"
          >
            {n}
          </button>
        ))}
        <button 
          onClick={() => onScore(25, multiplier > 2 ? 1 : multiplier)}
          className="aspect-square flex flex-col items-center justify-center bg-indigo-600/20 hover:bg-indigo-600/40 rounded-xl font-black text-sm text-indigo-400 border border-indigo-500/20 transition-all active:scale-95"
        >
          {multiplier === 2 ? 'DBull' : 'Bull'}
        </button>
        <button 
          onClick={() => onScore(0, 1)}
          className="aspect-square flex items-center justify-center bg-red-500/10 hover:bg-red-500/20 rounded-xl font-black text-xs text-red-500 border border-red-500/20 transition-all active:scale-95"
        >
          MISS
        </button>
      </div>
    </div>
  );
};

export default NumberInput;
