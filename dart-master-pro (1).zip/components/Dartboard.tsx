
import React from 'react';

interface DartboardProps {
  onScore: (value: number, multiplier: number) => void;
}

const Dartboard: React.FC<DartboardProps> = ({ onScore }) => {
  const numbers = [20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5];

  const polarToCartesian = (centerX: number, centerY: number, radius: number, angleInDegrees: number) => {
    const angleInRadians = (angleInDegrees) * Math.PI / 180.0;
    return {
      x: centerX + (radius * Math.cos(angleInRadians)),
      y: centerY + (radius * Math.sin(angleInRadians))
    };
  };

  const createSectorPath = (innerR: number, outerR: number, angleStart: number, angleEnd: number) => {
    const startOuter = polarToCartesian(250, 250, outerR, angleStart);
    const endOuter = polarToCartesian(250, 250, outerR, angleEnd);
    const startInner = polarToCartesian(250, 250, innerR, angleStart);
    const endInner = polarToCartesian(250, 250, innerR, angleEnd);
    return `M ${startOuter.x} ${startOuter.y} A ${outerR} ${outerR} 0 0 1 ${endOuter.x} ${endOuter.y} L ${endInner.x} ${endInner.y} A ${innerR} ${innerR} 0 0 0 ${startInner.x} ${startInner.y} Z`;
  };

  const renderSlice = (number: number, index: number) => {
    const angleStart = (index * 18 - 9) - 90;
    const angleEnd = angleStart + 18;
    const isEven = index % 2 === 0;
    
    const black = '#111111';
    const sisal = '#eee0bc';
    const red = '#b81423';
    const green = '#1a6b32';

    return (
      <g key={number} className="dart-sector cursor-pointer select-none">
        <path d={createSectorPath(135, 205, angleStart, angleEnd)} fill={isEven ? black : sisal} className="hover:brightness-125 transition-all" onClick={(e) => { e.stopPropagation(); onScore(number, 1); }} />
        <path d={createSectorPath(25, 120, angleStart, angleEnd)} fill={isEven ? black : sisal} className="hover:brightness-125 transition-all" onClick={(e) => { e.stopPropagation(); onScore(number, 1); }} />
        <path d={createSectorPath(205, 222, angleStart, angleEnd)} fill={isEven ? red : green} className="hover:brightness-150 transition-all" onClick={(e) => { e.stopPropagation(); onScore(number, 2); }} />
        <path d={createSectorPath(120, 137, angleStart, angleEnd)} fill={isEven ? red : green} className="hover:brightness-150 transition-all" onClick={(e) => { e.stopPropagation(); onScore(number, 3); }} />
        
        <text 
          x={polarToCartesian(250, 250, 238, (angleStart + angleEnd) / 2).x}
          y={polarToCartesian(250, 250, 238, (angleStart + angleEnd) / 2).y}
          fill="white" fontSize="16" fontWeight="900" textAnchor="middle" dominantBaseline="middle" className="pointer-events-none"
        >
          {number}
        </text>
      </g>
    );
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-4">
      <svg viewBox="0 0 500 500" className="w-full h-full max-w-[600px] drop-shadow-2xl" onClick={() => onScore(0, 1)}>
        <circle cx="250" cy="250" r="250" fill="#000" />
        <circle cx="250" cy="250" r="225" fill="#111" />
        {numbers.map((num, i) => renderSlice(num, i))}
        <g className="cursor-pointer transition-transform hover:scale-110">
          <circle cx="250" cy="250" r="25" fill="#1a6b32" stroke="#000" strokeWidth="0.5" onClick={(e) => { e.stopPropagation(); onScore(25, 1); }} />
          <circle cx="250" cy="250" r="10" fill="#b81423" stroke="#000" strokeWidth="0.5" onClick={(e) => { e.stopPropagation(); onScore(25, 2); }} />
        </g>
        <g pointerEvents="none" stroke="#666" strokeWidth="0.8" fill="none" opacity="0.4">
          <circle cx="250" cy="250" r="222" /><circle cx="250" cy="250" r="205" /><circle cx="250" cy="250" r="137" /><circle cx="250" cy="250" r="120" /><circle cx="250" cy="250" r="25" />
          {[...Array(20)].map((_, i) => {
            const p1 = polarToCartesian(250, 250, 25, i * 18 - 9);
            const p2 = polarToCartesian(250, 250, 222, i * 18 - 9);
            return <line key={i} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} />;
          })}
        </g>
      </svg>
    </div>
  );
};

export default Dartboard;
