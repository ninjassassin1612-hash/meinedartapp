
import React, { useState } from 'react';
import { GameMode, PersistentPlayer } from '../types';

interface SetupScreenProps {
  playerPool: PersistentPlayer[];
  onStart: (mode: GameMode, selectedPlayers: PersistentPlayer[], target: number) => void;
  onShowStats: () => void;
  onShowAudio: () => void;
  onManagePlayers: () => void;
}

const getFlagUrl = (code: string) => `https://flagcdn.com/w80/${code.toLowerCase()}.png`;

const SetupScreen: React.FC<SetupScreenProps> = ({ playerPool, onStart, onShowStats, onShowAudio, onManagePlayers }) => {
  const [mode, setMode] = useState<GameMode>(GameMode.X01);
  const [target, setTarget] = useState<number>(501);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const togglePlayer = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else if (selectedIds.length < 5) {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const activePlayers = playerPool.filter(p => selectedIds.includes(p.id));

  return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-slate-950 overflow-hidden">
      <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="hidden lg:block">
           <div className="w-16 h-2 bg-indigo-500 mb-8 rounded-full" />
           <h1 className="text-7xl font-black italic tracking-tighter leading-[0.85] mb-6 text-white uppercase">DART<br />MASTER<br /><span className="text-indigo-400">PRO EDITION</span></h1>
           <p className="text-slate-400 text-xl font-medium max-w-sm mb-12 italic">Das ultimative Scoring-Erlebnis für dein Tablet.</p>
           <div className="flex flex-col gap-4">
             <button onClick={onManagePlayers} className="glass px-8 py-5 rounded-[2rem] border border-white/10 text-white font-black italic text-lg hover:bg-white/5 transition-all flex items-center gap-4">
               <span className="text-2xl">👥</span> PROFIL-VERWALTUNG
             </button>
             <button onClick={onShowStats} className="glass px-8 py-5 rounded-[2rem] border border-white/10 text-indigo-400 font-black italic text-lg hover:bg-white/5 transition-all flex items-center gap-4">
               <span className="text-2xl">📊</span> HALL OF FAME
             </button>
             <button onClick={onShowAudio} className="glass px-8 py-5 rounded-[2rem] border border-white/10 text-slate-400 font-black italic text-lg hover:bg-white/5 transition-all flex items-center gap-4">
               <span className="text-2xl">⚙️</span> SYSTEM-SETUP
             </button>
           </div>
        </div>

        <div className="glass p-10 rounded-[3.5rem] shadow-2xl space-y-8 border border-white/10 relative">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-4">MATCH SETUP</label>
            <div className="flex flex-wrap gap-2">
              {[GameMode.X01, GameMode.CRICKET, GameMode.AROUND_THE_CLOCK, GameMode.HIGH_SCORE, GameMode.SHANGHAI].map(m => (
                <button key={m} onClick={() => setMode(m)} className={`px-4 py-2 rounded-xl font-black transition-all text-[10px] uppercase ${mode === m ? 'bg-indigo-600 text-white' : 'bg-slate-900/50 text-slate-500 hover:text-slate-300'}`}>{m}</button>
              ))}
            </div>
          </div>

          {mode === GameMode.X01 && (
            <div className="flex gap-2 animate-in slide-in-from-top-2">
              {[301, 501, 701].map(v => (
                <button key={v} onClick={() => setTarget(v)} className={`flex-1 py-3 rounded-xl font-black text-xs transition-all ${target === v ? 'bg-white text-slate-950' : 'bg-slate-900 text-slate-600 border border-white/5'}`}>{v}</button>
              ))}
            </div>
          )}

          <div>
            <div className="flex justify-between items-center mb-4">
              <label className="text-[10px] font-black uppercase tracking-widest text-indigo-400">WER TRITT AN? (Max 5)</label>
              <button onClick={onManagePlayers} className="text-[9px] font-black text-white/50 hover:text-white transition-all underline">NEUER SPIELER</button>
            </div>
            
            <div className="grid grid-cols-2 gap-3 max-h-[320px] overflow-y-auto pr-2 custom-scrollbar">
              {playerPool.map(p => {
                const isSelected = selectedIds.includes(p.id);
                return (
                  <button 
                    key={p.id}
                    onClick={() => togglePlayer(p.id)}
                    className={`p-4 rounded-3xl border-2 transition-all flex items-center gap-4 text-left ${isSelected ? 'bg-indigo-600/20 border-indigo-500' : 'bg-slate-900/50 border-white/5 opacity-60 hover:opacity-100'}`}
                  >
                    <img src={getFlagUrl(p.countryCode)} alt={p.countryCode} className="w-10 h-7 rounded shadow-md object-cover" />
                    <div className="min-w-0">
                      <p className="text-sm font-black text-white truncate">{p.dartName}</p>
                      <p className="text-[9px] font-bold text-slate-500 uppercase truncate italic">"{p.funnyAnswers.schrei}"</p>
                    </div>
                  </button>
                );
              })}
              {playerPool.length === 0 && (
                <div className="col-span-full py-12 text-center bg-slate-950/50 rounded-[2rem] border border-dashed border-white/10 cursor-pointer" onClick={onManagePlayers}>
                  <p className="text-indigo-400 text-xs font-black uppercase tracking-tighter">⚠️ Keine Spieler gefunden</p>
                  <p className="text-slate-600 text-[10px] font-bold uppercase mt-2">Klicke hier, um Profile anzulegen!</p>
                </div>
              )}
            </div>
          </div>

          <button 
            disabled={activePlayers.length === 0}
            onClick={() => onStart(mode, activePlayers, target)} 
            className="w-full py-6 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 text-white rounded-[2.5rem] font-black text-2xl italic transition-all shadow-xl active:scale-95 uppercase tracking-tighter flex items-center justify-center gap-4"
          >
            LET'S PLAY DARTS! 🎯
          </button>
        </div>
      </div>
    </div>
  );
};

export default SetupScreen;
