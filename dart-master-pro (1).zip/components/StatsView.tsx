
import React, { useState, useMemo } from 'react';
import { GameMode, GameState, GameResult } from '../types';

interface StatsViewProps {
  onClose: () => void;
  currentGame: GameState | null;
}

type TabType = 'current' | 'alltime' | 'monthly';

const StatsView: React.FC<StatsViewProps> = ({ onClose, currentGame }) => {
  const [activeTab, setActiveTab] = useState<TabType>(currentGame ? 'current' : 'alltime');

  const allResults: GameResult[] = useMemo(() => {
    const saved = localStorage.getItem('dart_results');
    return saved ? JSON.parse(saved) : [];
  }, []);

  const monthlyResults = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    return allResults.filter(r => {
      const d = new Date(r.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
  }, [allResults]);

  const aggregateStats = (results: GameResult[]) => {
    const playerMap: Record<string, any> = {};

    results.forEach(game => {
      game.players.forEach(p => {
        if (!playerMap[p.name]) {
          playerMap[p.name] = {
            games: 0,
            wins: 0,
            totalPoints: 0,
            totalDarts: 0,
            highScores: { sixtyPlus: 0, hundredPlus: 0, hundredFortyPlus: 0, oneEighty: 0 }
          };
        }
        const s = playerMap[p.name];
        s.games++;
        if (p.isWinner) s.wins++;
        s.totalPoints += p.totalPoints;
        s.totalDarts += p.totalDarts;
        s.highScores.sixtyPlus += p.highScores.sixtyPlus;
        s.highScores.hundredPlus += p.highScores.hundredPlus;
        s.highScores.hundredFortyPlus += p.highScores.hundredFortyPlus;
        s.highScores.oneEighty += p.highScores.oneEighty;
      });
    });

    return Object.entries(playerMap).map(([name, stats]) => ({
      name,
      ...stats,
      avgPPD: stats.totalDarts > 0 ? stats.totalPoints / stats.totalDarts : 0,
      winRate: stats.games > 0 ? (stats.wins / stats.games) * 100 : 0
    })).sort((a, b) => b.avgPPD - a.avgPPD);
  };

  const currentStats = useMemo(() => {
    if (!currentGame) return [];
    return currentGame.players.map(p => {
      const allThrows = [...p.history.flat(), ...currentGame.currentTurnThrows];
      const totalPoints = allThrows.reduce((acc, t) => acc + t.total, 0);
      const totalDarts = allThrows.length;
      
      const highScores = { sixtyPlus: 0, hundredPlus: 0, hundredFortyPlus: 0, oneEighty: 0 };
      p.history.forEach(turn => {
        const turnSum = turn.reduce((acc, t) => acc + t.total, 0);
        if (turnSum === 180) highScores.oneEighty++;
        else if (turnSum >= 140) highScores.hundredFortyPlus++;
        else if (turnSum >= 100) highScores.hundredPlus++;
        else if (turnSum >= 60) highScores.sixtyPlus++;
      });

      return {
        name: p.name,
        avgPPD: totalDarts > 0 ? totalPoints / totalDarts : 0,
        totalPoints,
        totalDarts,
        highScores
      };
    });
  }, [currentGame]);

  const displayData = activeTab === 'current' ? currentStats : aggregateStats(activeTab === 'monthly' ? monthlyResults : allResults);

  return (
    <div className="h-screen flex flex-col p-8 gap-8 overflow-hidden bg-slate-950">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-black italic text-white tracking-tighter">WURFAUSWERTUNG</h1>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-xs mt-1">Detaillierte Spielerstatistiken</p>
        </div>
        <button 
          onClick={onClose}
          className="bg-white/5 hover:bg-white/10 text-white px-8 py-4 rounded-3xl font-black text-lg border border-white/10 transition-all active:scale-95"
        >
          SCHLIESSEN
        </button>
      </div>

      <div className="flex gap-2 p-1.5 bg-slate-900 rounded-[2rem] border border-white/5 w-fit">
        {currentGame && (
          <button 
            onClick={() => setActiveTab('current')}
            className={`px-8 py-3 rounded-2xl font-black transition-all ${activeTab === 'current' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
          >
            AKTUELL
          </button>
        )}
        <button 
          onClick={() => setActiveTab('monthly')}
          className={`px-8 py-3 rounded-2xl font-black transition-all ${activeTab === 'monthly' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
        >
          DIESER MONAT
        </button>
        <button 
          onClick={() => setActiveTab('alltime')}
          className={`px-8 py-3 rounded-2xl font-black transition-all ${activeTab === 'alltime' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'text-slate-500 hover:text-slate-300'}`}
        >
          ALLTIME
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {displayData.map((p: any, i) => (
            <div key={i} className="glass p-8 rounded-[2.5rem] border border-white/5 shadow-2xl animate-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center font-black text-2xl text-white italic">
                    {p.name[0].toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white">{p.name}</h3>
                    {activeTab !== 'current' && <p className="text-slate-500 text-xs font-bold">{p.games} Spiele • {(p.winRate || 0).toFixed(1)}% Siegquote</p>}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block mb-1">Average PPD</span>
                  <span className="text-5xl font-black text-white italic tracking-tighter">{(p.avgPPD || 0).toFixed(2)}</span>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4 mb-8">
                <div className="bg-slate-950/50 p-4 rounded-3xl border border-white/5 text-center">
                  <span className="text-[10px] font-black text-slate-500 block mb-1">60+</span>
                  <span className="text-xl font-black text-white">{p.highScores.sixtyPlus}</span>
                </div>
                <div className="bg-slate-950/50 p-4 rounded-3xl border border-white/5 text-center">
                  <span className="text-[10px] font-black text-slate-500 block mb-1">100+</span>
                  <span className="text-xl font-black text-white">{p.highScores.hundredPlus}</span>
                </div>
                <div className="bg-slate-950/50 p-4 rounded-3xl border border-white/5 text-center">
                  <span className="text-[10px] font-black text-slate-500 block mb-1">140+</span>
                  <span className="text-xl font-black text-white">{p.highScores.hundredFortyPlus}</span>
                </div>
                <div className="bg-indigo-600/10 p-4 rounded-3xl border border-indigo-500/20 text-center">
                  <span className="text-[10px] font-black text-indigo-400 block mb-1">180</span>
                  <span className="text-xl font-black text-white">{p.highScores.oneEighty}</span>
                </div>
              </div>

              <div className="flex justify-between text-xs font-bold text-slate-400 px-2">
                <span>Darts: {p.totalDarts}</span>
                <span>Punkte: {p.totalPoints}</span>
              </div>
            </div>
          ))}
        </div>

        {displayData.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 gap-4 opacity-50">
             <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center border border-white/10">
               <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
             </div>
             <span className="font-black tracking-widest uppercase">Keine Daten verfügbar</span>
          </div>
        )}
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default StatsView;
