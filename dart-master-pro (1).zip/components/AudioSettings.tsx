
import React, { useState } from 'react';
import { AppSettings, VoiceProfile, ScoreboardViewMode, InputMode } from '../types';

interface AudioSettingsProps {
  settings: AppSettings;
  onUpdate: (s: AppSettings) => void;
  onTestVoice: (text: string, overrideProfile?: VoiceProfile) => Promise<void>;
  onClose: () => void;
  onGlobalReset: () => void;
}

const LANGUAGES = ['Deutsch', 'English', 'Español', 'Français', '中文', '日本語'];

const PROFILES: { id: VoiceProfile; name: string; icon: string; desc: string; testPhrase: string }[] = [
  { id: 'MAN', name: 'Mann', icon: '👨', desc: 'Sagt Punkte an & macht Witze', testPhrase: "Warum haben Männer keine Zellulite? Weil es scheiße aussieht. Haha!" },
  { id: 'WOMAN', name: 'Frau', icon: '👩', desc: 'Meckert über deine Würfe', testPhrase: "Musst du eigentlich immer die Socken überall liegen lassen?" },
  { id: 'GOAT', name: 'Ziege', icon: '🐐', desc: 'Meckert wie eine Ziege', testPhrase: "Meeeeh! Das war ein furchtbarer Wurf! Meeeeh!" },
  { id: 'EXCITED', name: 'Aufgeregt', icon: '🔥', desc: 'Extrem motiviert & laut', testPhrase: "EINS-HUNDERT-ACHTZIG!!!! GIB ALLES!!!!" },
  { id: 'CHEEKY', name: 'Frech', icon: '😜', desc: 'Witzig & Sarkastisch', testPhrase: "Oh, toller Wurf. Hast du die Dartscheibe überhaupt gesucht?" },
];

const AudioSettings: React.FC<AudioSettingsProps> = ({ settings, onUpdate, onTestVoice, onClose, onGlobalReset }) => {
  const [testingId, setTestingId] = useState<VoiceProfile | null>(null);

  const runVoiceTest = async (phrase: string, id: VoiceProfile) => {
    setTestingId(id);
    try { await onTestVoice(phrase, id); } finally { setTestingId(null); }
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="max-w-4xl w-full p-8 bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl overflow-y-auto max-h-[95vh]">
        <div className="flex justify-between items-center mb-8">
          <div><h2 className="text-3xl font-black italic text-white tracking-tighter uppercase">EINSTELLUNGEN</h2><p className="text-indigo-400 font-bold uppercase tracking-widest text-[10px]">Anpassung von Audio & UI</p></div>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-full transition-all"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2" strokeLinecap="round"/></svg></button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <section>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Lautstärke: {settings.volume}%</h3>
              <input type="range" min="0" max="100" value={settings.volume} onChange={(e) => onUpdate({...settings, volume: parseInt(e.target.value)})} className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
            </section>

            <section>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Stimmenprofil</h3>
              <div className="space-y-2">
                {PROFILES.map(p => (
                  <div key={p.id} className="relative flex items-center gap-2">
                    <button onClick={() => onUpdate({ ...settings, voiceProfile: p.id })} className={`flex-1 flex items-center gap-3 p-3 rounded-xl border-2 transition-all text-left ${settings.voiceProfile === p.id ? 'bg-indigo-600/20 border-indigo-500' : 'bg-slate-950 border-white/5'}`}>
                      <span className="text-xl">{p.icon}</span>
                      <div className="flex-1 text-xs"><p className="font-black text-white">{p.name}</p><p className="opacity-40">{p.desc}</p></div>
                    </button>
                    <button onClick={() => runVoiceTest(p.testPhrase, p.id)} disabled={testingId !== null} className={`p-3 rounded-xl border border-white/5 ${testingId === p.id ? 'bg-indigo-500 animate-pulse' : 'bg-white/5 text-indigo-400'}`}><svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"/></svg></button>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="space-y-6">
            <section>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Eingabe-Modus</h3>
              <div className="grid grid-cols-1 gap-2">
                {[
                  {id: 'BOARD', name: 'Nur Dartscheibe', icon: '🎯'},
                  {id: 'BOTH', name: 'Scheibe & Tasten', icon: '⌨️'},
                  {id: 'NUMBERS', name: 'Nur Tasten', icon: '🔢'}
                ].map(m => (
                  <button key={m.id} onClick={() => onUpdate({...settings, inputMode: m.id as InputMode})} className={`p-4 rounded-xl border-2 flex items-center gap-3 font-bold text-sm transition-all ${settings.inputMode === m.id ? 'bg-indigo-600/20 border-indigo-500 text-white' : 'bg-slate-950 border-white/5 text-slate-500'}`}><span>{m.icon}</span>{m.name}</button>
                ))}
              </div>
            </section>

            <section>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">App Verwaltung</h3>
              <button onClick={onGlobalReset} className="w-full py-4 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white border border-red-500/20 rounded-xl font-black text-xs uppercase transition-all">Gesamte App zurücksetzen</button>
            </section>
          </div>
        </div>

        <button onClick={onClose} className="w-full mt-10 py-5 bg-white text-slate-900 rounded-2xl font-black text-lg hover:bg-indigo-50 transition-all shadow-xl active:scale-95">ÜBERNEHMEN</button>
      </div>
    </div>
  );
};

export default AudioSettings;
