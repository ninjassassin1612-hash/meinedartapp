
import React, { useState } from 'react';
import { PersistentPlayer } from '../types';

interface PlayerManagementProps {
  pool: PersistentPlayer[];
  setPool: React.Dispatch<React.SetStateAction<PersistentPlayer[]>>;
  onClose: () => void;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#14b8a6', '#475569'];

const FLAGS = [
  { code: 'de', name: 'Deutschland' }, { code: 'at', name: 'Österreich' }, { code: 'ch', name: 'Schweiz' },
  { code: 'gb', name: 'UK' }, { code: 'nl', name: 'Niederlande' }, { code: 'be', name: 'Belgien' },
  { code: 'us', name: 'USA' }, { code: 'au', name: 'Australien' }, { code: 'jp', name: 'Japan' },
  { code: 'ie', name: 'Irland' }, { code: 'pl', name: 'Polen' }, { code: 'cz', name: 'Tschechien' },
  { code: 'es', name: 'Spanien' }, { code: 'fr', name: 'Frankreich' }, { code: 'it', name: 'Italien' },
  { code: 'dk', name: 'Dänemark' }, { code: 'ca', name: 'Kanada' }, { code: 'nz', name: 'Neuseeland' },
  { code: 'za', name: 'Südafrika' }, { code: 'pt', name: 'Portugal' }, { code: 'se', name: 'Schweden' },
  { code: 'no', name: 'Norwegen' }, { code: 'fi', name: 'Finnland' }, { code: 'gr', name: 'Griechenland' }
];

const getFlagUrl = (code: string) => `https://flagcdn.com/w80/${code.toLowerCase()}.png`;

const PlayerManagement: React.FC<PlayerManagementProps> = ({ pool, setPool, onClose }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<PersistentPlayer>>({
    name: '',
    dartName: '',
    throwingArm: 'Rechts',
    countryCode: 'de',
    funnyAnswers: { zielwasser: '', ausrede: '', schrei: '', unfall: '' }
  });

  const savePlayer = () => {
    if (form.name?.trim()) {
      const playerData: PersistentPlayer = {
        id: editingId || `pp-${Date.now()}`,
        name: form.name!.trim(),
        dartName: form.dartName?.trim() || form.name!.trim(),
        throwingArm: form.throwingArm || 'Rechts',
        countryCode: form.countryCode || 'de',
        avatarColor: form.avatarColor || COLORS[pool.length % COLORS.length],
        createdAt: Date.now(),
        funnyAnswers: {
          zielwasser: form.funnyAnswers?.zielwasser || 'Keins',
          ausrede: form.funnyAnswers?.ausrede || 'Windig hier',
          schrei: form.funnyAnswers?.schrei || 'Yesss!',
          unfall: form.funnyAnswers?.unfall || 'Zu viele'
        }
      };

      if (editingId) {
        setPool(pool.map(p => p.id === editingId ? playerData : p));
      } else {
        if (pool.length >= 10) return alert("Maximal 10 Spieler möglich!");
        setPool([...pool, playerData]);
      }
      resetForm();
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setForm({
      name: '',
      dartName: '',
      throwingArm: 'Rechts',
      countryCode: 'de',
      funnyAnswers: { zielwasser: '', ausrede: '', schrei: '', unfall: '' }
    });
  };

  const startEdit = (p: PersistentPlayer) => {
    setEditingId(p.id);
    setForm(p);
  };

  return (
    <div className="fixed inset-0 z-[300] bg-slate-950 flex items-center justify-center p-4 backdrop-blur-2xl">
      <div className="glass max-w-5xl w-full h-[90vh] flex flex-col p-8 rounded-[3rem] border border-white/10 shadow-2xl overflow-hidden">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-3xl font-black italic uppercase text-white">PROFIL-VERWALTUNG</h2>
            <p className="text-indigo-400 font-bold uppercase text-[10px] tracking-widest">{pool.length} / 10 Spieler</p>
          </div>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth="2" strokeLinecap="round"/></svg>
          </button>
        </div>

        <div className="flex-1 flex gap-8 min-h-0 overflow-hidden">
          {/* List Section */}
          <div className="w-1/3 flex flex-col gap-3 overflow-y-auto pr-2 custom-scrollbar">
            {pool.map(p => (
              <div key={p.id} className={`p-4 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${editingId === p.id ? 'bg-indigo-600 border-indigo-400' : 'bg-white/5 border-white/5 hover:border-white/10'}`} onClick={() => startEdit(p)}>
                <div className="flex items-center gap-3">
                  <img src={getFlagUrl(p.countryCode)} alt={p.countryCode} className="w-8 h-5 rounded shadow-sm object-cover" />
                  <div className="truncate">
                    <p className="font-black text-white text-sm truncate">{p.dartName}</p>
                    <p className="text-[10px] text-white/50">{p.name}</p>
                  </div>
                </div>
                <button onClick={(e) => { e.stopPropagation(); setPool(pool.filter(pl => pl.id !== p.id)); }} className="text-red-500 hover:scale-110 p-1">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2" strokeLinecap="round"/></svg>
                </button>
              </div>
            ))}
            {pool.length < 10 && !editingId && (
              <button onClick={resetForm} className="p-4 border-2 border-dashed border-white/10 rounded-2xl text-slate-500 font-black text-xs uppercase hover:border-indigo-500 hover:text-indigo-500 transition-all">
                + Neuen Spieler anlegen
              </button>
            )}
          </div>

          {/* Form Section */}
          <div className="flex-1 bg-white/5 rounded-[2.5rem] p-8 overflow-y-auto custom-scrollbar border border-white/5">
            <h3 className="text-lg font-black text-indigo-400 uppercase mb-6">{editingId ? 'PROFIL BEARBEITEN' : 'NEUES PROFIL'}</h3>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-2 tracking-widest">Echter Name</label>
                  <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-2xl text-white font-bold" placeholder="z.B. Phil Taylor" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-2 tracking-widest">Dart-Name (Spitzname)</label>
                  <input value={form.dartName} onChange={e => setForm({...form, dartName: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-2xl text-white font-bold" placeholder="z.B. The Power" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-2 tracking-widest">Wurfarm</label>
                  <div className="flex gap-2">
                    {['Rechts', 'Links'].map(arm => (
                      <button key={arm} onClick={() => setForm({...form, throwingArm: arm as any})} className={`flex-1 py-3 rounded-xl font-black text-xs uppercase transition-all ${form.throwingArm === arm ? 'bg-indigo-600 text-white' : 'bg-slate-950 text-slate-600 border border-white/5'}`}>{arm}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-2 tracking-widest">Nationalität</label>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 bg-slate-950 p-3 rounded-2xl border border-white/10 h-[120px] overflow-y-auto custom-scrollbar">
                    {FLAGS.map(f => (
                      <button 
                        key={f.code} 
                        onClick={() => setForm({...form, countryCode: f.code})} 
                        className={`p-1 rounded-lg transition-all flex items-center justify-center border-2 ${form.countryCode === f.code ? 'bg-indigo-600 border-indigo-400' : 'bg-transparent border-transparent hover:bg-white/5'}`} 
                        title={f.name}
                      >
                        <img src={getFlagUrl(f.code)} alt={f.name} className="w-full h-auto rounded-sm shadow-sm" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase text-indigo-400 tracking-widest block border-b border-white/5 pb-2">Die "harten" Fragen zum Schmunzeln</label>
                
                <div className="space-y-4">
                  <div className="space-y-1">
                    <p className="text-xs text-slate-400 italic">"Wie viel Zielwasser hast du heute schon getankt?"</p>
                    <input value={form.funnyAnswers?.zielwasser} onChange={e => setForm({...form, funnyAnswers: {...form.funnyAnswers!, zielwasser: e.target.value}})} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white text-sm" placeholder="Antwort..." />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-slate-400 italic">"Deine Ausrede für Würfe außerhalb des Boards?"</p>
                    <input value={form.funnyAnswers?.ausrede} onChange={e => setForm({...form, funnyAnswers: {...form.funnyAnswers!, ausrede: e.target.value}})} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white text-sm" placeholder="Antwort..." />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-slate-400 italic">"Dein Kampfschrei bei einer 180?"</p>
                    <input value={form.funnyAnswers?.schrei} onChange={e => setForm({...form, funnyAnswers: {...form.funnyAnswers!, schrei: e.target.value}})} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white text-sm" placeholder="Antwort..." />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-slate-400 italic">"Wie viele Darts stecken schon dauerhaft im Teppich?"</p>
                    <input value={form.funnyAnswers?.unfall} onChange={e => setForm({...form, funnyAnswers: {...form.funnyAnswers!, unfall: e.target.value}})} className="w-full bg-slate-950 border border-white/5 p-3 rounded-xl text-white text-sm" placeholder="Antwort..." />
                  </div>
                </div>
              </div>

              <button onClick={savePlayer} className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black text-lg uppercase shadow-xl transition-all">
                PROFIL SPEICHERN
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerManagement;
