
import React from 'react';
import { GameState, GameMode, ScoreboardViewMode } from '../types';

interface ScoreboardProps {
  gameState: GameState;
  viewMode: ScoreboardViewMode;
}

const getFlagUrl = (code: string) => `https://flagcdn.com/w80/${code.toLowerCase()}.png`;

const Scoreboard: React.FC<ScoreboardProps> = ({ gameState, viewMode }) => {
  const isCricket = gameState.mode === GameMode.CRICKET;
  const isATC = gameState.mode === GameMode.AROUND_THE_CLOCK;

  const calculateStats = (history: any[][], currentThrows: any[]) => {
    const allTurns = [...history];
    if (currentThrows.length > 0) allTurns.push(currentThrows);
    
    const allThrowsFlat = allTurns.flat();
    const totalPoints = allThrowsFlat.reduce((acc, t) => acc + t.total, 0);
    const totalDarts = allThrowsFlat.length;
    
    const ppd = totalDarts > 0 ? totalPoints / totalDarts : 0;
    
    const first9Points = allTurns.slice(0, 3).flat().reduce((acc, t) => acc + t.total, 0);
    const first9Darts = allTurns.slice(0, 3).flat().length;
    const first9Avg = first9Darts > 0 ? (first9Points / first9Darts) * 3 : 0;

    const highScores = { s60: 0, s100: 0, s140: 0, s180: 0 };
    history.forEach(turn => {
      const sum = turn.reduce((acc, t) => acc + t.total, 0);
      if (sum === 180) highScores.s180++;
      else if (sum >= 140) highScores.s140++;
      else if (sum >= 100) highScores.s100++;
      else if (sum >= 60) highScores.s60++;
    });

    return { ppd, first9Avg, highScores, totalDarts };
  };

  return (
    <div className="flex-1 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar">
      {gameState.players.map((player, idx) => {
        const isActive = gameState.currentPlayerIndex === idx;
        const stats = calculateStats(player.history, isActive ? gameState.currentTurnThrows : []);
        
        return (
          <div 
            key={player.id}
            className={`rounded-[2rem] border-2 transition-all duration-500 overflow-hidden flex flex-col ${
              isActive 
                ? 'bg-indigo-600/20 border-indigo-500 shadow-2xl shadow-indigo-900/30 translate-x-1' 
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="p-4 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <img src={getFlagUrl(player.countryCode)} alt={player.countryCode} className="w-8 h-5 rounded shadow-sm object-cover" />
                <div className="min-w-0">
                   <span className={`text-base font-black block truncate leading-tight ${isActive ? 'text-white' : 'text-slate-400'}`}>
                    {player.dartName}
                  </span>
                  <span className="text-[9px] font-bold text-slate-500 uppercase truncate block">
                    {player.name}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-4xl font-black tracking-tighter italic leading-none ${isActive ? 'text-white' : 'text-slate-300'}`}>
                  {player.score}
                </div>
              </div>
            </div>

            {viewMode === 'MASTER' && (
              <div className="bg-black/20 p-3 border-t border-white/5 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-white/5 p-1.5 rounded-xl text-center">
                    <p className="text-[7px] font-black text-indigo-400 uppercase tracking-widest leading-tight">3-Dart Avg</p>
                    <p className="text-base font-black text-white italic">{(stats.ppd * 3).toFixed(1)}</p>
                  </div>
                  <div className="bg-white/5 p-1.5 rounded-xl text-center">
                    <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest leading-tight">Darts</p>
                    <p className="text-base font-black text-slate-300 italic">{stats.totalDarts}</p>
                  </div>
                </div>

                <div className="flex justify-between px-2">
                  {[60, 100, 140, 180].map(val => (
                    <div key={val} className="text-center">
                      <p className="text-[7px] font-black text-slate-600 uppercase">{val}+</p>
                      <p className={`text-xs font-black ${stats.highScores[`s${val}` as keyof typeof stats.highScores] > 0 ? 'text-white' : 'text-slate-800'}`}>
                        {stats.highScores[`s${val}` as keyof typeof stats.highScores]}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {isCricket && player.cricketStats && (
              <div className="grid grid-cols-7 gap-0.5 p-3 border-t border-white/5 bg-white/2">
                {[20, 19, 18, 17, 16, 15, 25].map(num => {
                  const hits = player.cricketStats![num] || 0;
                  return (
                    <div key={num} className="flex flex-col items-center gap-1">
                      <span className={`text-[8px] font-black ${hits >= 3 ? 'text-green-400' : 'text-slate-600'}`}>
                        {num === 25 ? 'B' : num}
                      </span>
                      <div className="flex flex-col gap-0.5 w-full max-w-[8px]">
                        {[1, 2, 3].map(h => (
                          <div key={h} className={`h-1 rounded-full ${hits >= h ? 'bg-indigo-400' : 'bg-slate-800'}`} />
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default Scoreboard;
