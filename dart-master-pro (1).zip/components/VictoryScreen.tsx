
import React, { useEffect } from 'react';
import { GameState, Player } from '../types';

interface VictoryScreenProps {
  gameState: GameState;
  onRematch: () => void;
  onHome: () => void;
  speak: (text: string) => void;
}

const getFlagUrl = (code: string) => `https://flagcdn.com/w160/${code.toLowerCase()}.png`;

const VictoryScreen: React.FC<VictoryScreenProps> = ({ gameState, onRematch, onHome, speak }) => {
  const winner = gameState.players.find(p => p.dartName === gameState.winner) || gameState.players[0];

  useEffect(() => {
    // Kurze Verzögerung für den Effekt, dann die Siegerrede
    const timer = setTimeout(() => {
      const speech = `Wahnsinn! Spiel Satz und Sieg für ${winner.dartName}! Ein verdienter Sieg mit Stil. Zeit für deinen Kampfschrei: ${winner.dartName}!`;
      speak(speech);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const calculatePlayerStats = (player: Player) => {
    const allThrows = player.history.flat();
    const totalPoints = allThrows.reduce((acc, t) => acc + t.total, 0);
    const totalDarts = allThrows.length;
    const avg = totalDarts > 0 ? (totalPoints / totalDarts) * 3 : 0;
    
    const scores = { s60: 0, s100: 0, s140: 0, s180: 0 };
    player.history.forEach(turn => {
      const sum = turn.reduce((acc, t) => acc + t.total, 0);
      if (sum === 180) scores.s180++;
      else if (sum >= 140) scores.s140++;
      else if (sum >= 100) scores.s100++;
      else if (sum >= 60) scores.s60++;
    });

    return { avg, totalDarts, scores };
  };

  return (
    <div className="fixed inset-0 z-[500] bg-slate-950 flex flex-col items-center justify-center p-8 overflow-y-auto overflow-x-hidden">
      {/* Background Glow Effects */}
      <div className="absolute inset-0 pointer-events-none opacity-50">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-600/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-amber-500/20 blur-[80px] rounded-full" />
      </div>

      <div className="relative z-10 w-full max-w-5xl flex flex-col items-center gap-8 animate-in zoom-in-95 duration-1000">
        {/* Winner Header */}
        <div className="text-center space-y-4">
          <div className="inline-block p-2 bg-amber-500 rounded-full shadow-[0_0_40px_rgba(245,158,11,0.5)] animate-bounce mb-4">
            <svg className="w-16 h-16 text-slate-950" fill="currentColor" viewBox="0 0 20 20">
              <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14s-2-2-5-2-5 2-5 2V4z" />
            </svg>
          </div>
          <h1 className="text-6xl font-black italic tracking-tighter uppercase text-white drop-shadow-2xl">CHAMPION</h1>
          <div className="flex items-center justify-center gap-6 bg-white/5 p-8 rounded-[3rem] border border-amber-500/30 shadow-2xl backdrop-blur-xl">
             <img src={getFlagUrl(winner.countryCode)} alt="Winner Flag" className="w-24 h-16 rounded-xl shadow-lg object-cover" />
             <div className="text-left">
               <h2 className="text-5xl font-black text-amber-400 italic tracking-tighter">{winner.dartName}</h2>
               <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">{winner.name}</p>
             </div>
          </div>
        </div>

        {/* Stats Table */}
        <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {gameState.players.map((p, i) => {
            const isWinner = p.dartName === gameState.winner;
            const stats = calculatePlayerStats(p);
            return (
              <div key={p.id} className={`glass p-6 rounded-[2.5rem] border transition-all ${isWinner ? 'border-amber-500/50 bg-amber-500/5 scale-105' : 'border-white/5'}`}>
                <div className="flex items-center gap-3 mb-4">
                  <img src={getFlagUrl(p.countryCode)} className="w-8 h-5 rounded shadow-sm" alt="flag" />
                  <span className={`font-black truncate ${isWinner ? 'text-amber-400' : 'text-white'}`}>{p.dartName}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-slate-950/50 p-3 rounded-2xl text-center">
                    <p className="text-[8px] font-black text-slate-500 uppercase">3-Dart Avg</p>
                    <p className="text-xl font-black text-white italic">{stats.avg.toFixed(1)}</p>
                  </div>
                  <div className="bg-slate-950/50 p-3 rounded-2xl text-center">
                    <p className="text-[8px] font-black text-slate-500 uppercase">Darts</p>
                    <p className="text-xl font-black text-white italic">{stats.totalDarts}</p>
                  </div>
                </div>
                <div className="flex justify-between px-2 text-[10px] font-black uppercase text-slate-600">
                  <span>100+: {stats.scores.s100}</span>
                  <span>140+: {stats.scores.s140}</span>
                  <span className="text-indigo-400">180: {stats.scores.s180}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-2xl mt-4">
          <button 
            onClick={onRematch}
            className="flex-1 py-6 bg-indigo-600 hover:bg-indigo-500 text-white rounded-[2rem] font-black text-2xl italic shadow-2xl transition-all active:scale-95 uppercase tracking-tighter"
          >
            🔄 Rückspiel
          </button>
          <button 
            onClick={onHome}
            className="flex-1 py-6 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-[2rem] font-black text-2xl italic transition-all active:scale-95 uppercase tracking-tighter"
          >
            🏠 Hauptmenü
          </button>
        </div>
      </div>
    </div>
  );
};

export default VictoryScreen;
