
import React, { useState, useEffect } from 'react';
import { GameMode } from '../types';

interface TutorialProps {
  mode: GameMode;
  onClose: () => void;
}

const Tutorial: React.FC<TutorialProps> = ({ mode, onClose }) => {
  const [dontShowAgain, setDontShowAgain] = useState(false);

  const tutorialContent = {
    [GameMode.X01]: {
      title: "X01 (Standard)",
      rules: [
        "Jeder Spieler startet mit 301, 501 oder 701 Punkten.",
        "Das Ziel ist es, exakt auf 0 zu kommen.",
        "Ein Wurf, der den Punktestand unter 0 oder auf genau 1 bringt, gilt als 'Bust' und der Zug endet."
      ]
    },
    [GameMode.CRICKET]: {
      title: "Cricket",
      rules: [
        "Ziel ist es, die Zahlen 15 bis 20 und das Bullseye 'zuzumachen'.",
        "Eine Zahl ist zu, wenn man sie 3 Mal getroffen hat (Triples zählen 3, Doubles 2).",
        "Punkte gibt es nur auf Zahlen, die man selbst zu hat, der Gegner aber noch nicht."
      ]
    },
    [GameMode.AROUND_THE_CLOCK]: {
      title: "Around the Clock",
      rules: [
        "Triff die Zahlen 1 bis 20 der Reihe nach.",
        "Multiplikatoren zählen nicht extra, es geht nur um die Reihenfolge.",
        "Wer zuerst die 20 (oder optional das Bullseye) trifft, gewinnt."
      ]
    },
    [GameMode.SHANGHAI]: {
      title: "Shanghai",
      rules: [
        "Gespielt werden 7 Runden (Zahlen 1 bis 7).",
        "In Runde 1 zählt nur die 1, in Runde 2 nur die 2, usw.",
        "Besonderer Sieg: Triff Single, Double und Triple der aktuellen Zahl in einem Zug!"
      ]
    },
    [GameMode.HIGH_SCORE]: {
      title: "High Score",
      rules: [
        "Sammle in 10 Runden so viele Punkte wie möglich.",
        "Alle Felder zählen normal mit ihren Multiplikatoren.",
        "Der Spieler mit der höchsten Punktzahl am Ende gewinnt."
      ]
    }
  };

  const content = tutorialContent[mode];

  const handleFinish = () => {
    if (dontShowAgain) {
      localStorage.setItem(`tutorial_disabled_${mode}`, 'true');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md p-6">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 text-white">
          <h2 className="text-3xl font-black italic tracking-tighter">ANLEITUNG: {content.title}</h2>
        </div>
        <div className="p-8 space-y-6">
          <ul className="space-y-4">
            {content.rules.map((rule, i) => (
              <li key={i} className="flex gap-4 items-start">
                <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  {i + 1}
                </span>
                <p className="text-slate-300 font-medium leading-relaxed">{rule}</p>
              </li>
            ))}
          </ul>

          <div className="pt-6 border-t border-slate-800 flex flex-col gap-4">
            <label className="flex items-center gap-3 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={dontShowAgain} 
                onChange={() => setDontShowAgain(!dontShowAgain)}
                className="w-5 h-5 rounded border-slate-700 bg-slate-950 text-indigo-500 focus:ring-indigo-500"
              />
              <span className="text-sm text-slate-400 group-hover:text-slate-200 transition-colors">Nicht mehr anzeigen</span>
            </label>
            <button 
              onClick={handleFinish}
              className="w-full py-4 bg-white text-slate-900 rounded-2xl font-black text-lg hover:bg-slate-200 transition-all active:scale-[0.98]"
            >
              VERSTANDEN
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tutorial;
