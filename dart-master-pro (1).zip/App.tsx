
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { GameMode, Player, Throw, GameState, GameResult, VoiceProfile, AppSettings, PersistentPlayer } from './types';
import Dartboard from './components/Dartboard';
import Scoreboard from './components/Scoreboard';
import SetupScreen from './components/SetupScreen';
import Tutorial from './components/Tutorial';
import StatsView from './components/StatsView';
import AudioSettings from './components/AudioSettings';
import NumberInput from './components/NumberInput';
import PlayerManagement from './components/PlayerManagement';
import VictoryScreen from './components/VictoryScreen';

function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}

const getFlagUrl = (code: string) => `https://flagcdn.com/w80/${code.toLowerCase()}.png`;

const CHECKOUT_GUIDE: Record<number, string[]> = {
  170: ["T20", "T20", "Bull"], 167: ["T20", "T19", "Bull"], 164: ["T20", "T18", "Bull"], 161: ["T20", "T17", "Bull"], 160: ["T20", "T20", "D20"],
  158: ["T20", "T20", "D19"], 157: ["T20", "T19", "D20"], 156: ["T20", "T20", "D18"], 155: ["T20", "T19", "D19"], 154: ["T20", "T18", "D20"],
  153: ["T20", "T19", "D18"], 152: ["T20", "T20", "D16"], 151: ["T20", "T17", "D20"], 150: ["T20", "T18", "D18"], 149: ["T20", "T19", "D16"],
  148: ["T20", "T16", "D20"], 147: ["T20", "T17", "D18"], 146: ["T20", "T18", "D16"], 145: ["T20", "T15", "D20"], 144: ["T20", "T20", "D12"],
  143: ["T20", "T17", "D16"], 142: ["T20", "T14", "D20"], 141: ["T20", "T15", "D18"], 140: ["T20", "T20", "D10"], 130: ["T20", "T20", "D5"],
  121: ["T20", "25", "Bull"], 110: ["T20", "10", "D20"], 100: ["T20", "D20"], 90: ["T20", "D15"], 80: ["T20", "D10"], 70: ["T10", "D20"],
  60: ["20", "D20"], 50: ["10", "D20"], 40: ["D20"], 32: ["D16"], 24: ["D12"], 20: ["D10"], 16: ["D8"], 8: ["D4"], 4: ["D2"], 2: ["D1"]
};

const getDynamicCheckout = (score: number): string[] | null => {
  if (score > 170 || score <= 1) return null;
  if (CHECKOUT_GUIDE[score]) return CHECKOUT_GUIDE[score];
  if (score <= 40 && score % 2 === 0) return [`D${score / 2}`];
  if (score <= 60) {
    const single = score - 32;
    if (single > 0) return [`${single}`, "D16"];
  }
  return null;
};

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [history, setHistory] = useState<GameState[]>([]);
  const [showStats, setShowStats] = useState(false);
  const [showAudioSettings, setShowAudioSettings] = useState(false);
  const [showPlayerManagement, setShowPlayerManagement] = useState(false);
  
  const [playerPool, setPlayerPool] = useState<PersistentPlayer[]>(() => {
    const saved = localStorage.getItem('dart_player_pool');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('dart_settings');
    return saved ? JSON.parse(saved) : { 
      voiceProfile: 'MAN', 
      language: 'Deutsch', 
      scoreboardView: 'MASTER',
      volume: 80,
      inputMode: 'BOARD'
    };
  });

  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const wakeLockRef = useRef<any>(null);

  useEffect(() => {
    localStorage.setItem('dart_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('dart_player_pool', JSON.stringify(playerPool));
  }, [playerPool]);

  useEffect(() => {
    const requestWakeLock = async () => {
      if ('wakeLock' in navigator && gameState && !gameState.isFinished && !wakeLockRef.current) {
        try {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        } catch (err: any) {
          console.warn(`Wake Lock Error: ${err.message}`);
        }
      }
    };
    requestWakeLock();
    return () => {
      if (wakeLockRef.current) {
        wakeLockRef.current.release().then(() => { wakeLockRef.current = null; });
      }
    };
  }, [gameState]);

  const initAudio = async () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    if (audioContextRef.current.state === 'suspended') {
      await audioContextRef.current.resume();
    }
    return audioContextRef.current;
  };

  const speakNative = (text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = settings.language === 'Deutsch' ? 'de-DE' : 'en-US';
    utterance.volume = settings.volume / 100;
    window.speechSynthesis.speak(utterance);
  };

  const speak = async (text: string, overrideProfile?: VoiceProfile) => {
    try {
      const ctx = await initAudio();
      const activeProfile = overrideProfile || settings.voiceProfile;
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: text }] }],
        config: {
          systemInstruction: `Du bist ein Dart-Kommentator namens "The Voice". Profil: ${activeProfile}. Du kommentierst Dart-Spiele live. Antworte extrem kurz, enthusiastisch und professionell. Sprache: ${settings.language}.`,
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } as any },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioBuffer = await decodeAudioData(decodeBase64(base64Audio), ctx);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        const gainNode = ctx.createGain();
        gainNode.gain.value = settings.volume / 100;
        source.connect(gainNode);
        gainNode.connect(ctx.destination);
        const now = ctx.currentTime;
        if (nextStartTimeRef.current < now) nextStartTimeRef.current = now;
        source.start(nextStartTimeRef.current);
        nextStartTimeRef.current += audioBuffer.duration;
      } else {
        speakNative(text);
      }
    } catch (e: any) {
      speakNative(text);
    }
  };

  const startGame = async (mode: GameMode, selectedPlayers: PersistentPlayer[], target: number) => {
    await initAudio(); 
    const players: Player[] = selectedPlayers.map((p) => ({
      id: p.id,
      name: p.name,
      dartName: p.dartName,
      countryCode: p.countryCode,
      score: mode === GameMode.X01 ? target : 0,
      history: [],
      cricketStats: mode === GameMode.CRICKET ? { 15: 0, 16: 0, 17: 0, 18: 0, 19: 0, 20: 0, 25: 0 } : undefined,
      atcNextTarget: mode === GameMode.AROUND_THE_CLOCK ? 1 : undefined,
      roundScores: []
    }));

    const newState: GameState = {
      mode,
      targetScore: target,
      players,
      currentPlayerIndex: 0,
      currentTurnThrows: [],
      isFinished: false,
      round: 1,
      startTime: Date.now()
    };

    setGameState(newState);
    setHistory([]);
    speak(`Game on! ${players[0].dartName} ist am Wurf.`);
  };

  const handleRematch = () => {
    if (!gameState) return;
    const currentPersistentPlayers = playerPool.filter(pp => 
      gameState.players.some(p => p.id === pp.id)
    );
    // Erhalte die Reihenfolge der ursprünglichen Auswahl
    const orderedPlayers = gameState.players.map(gp => 
      playerPool.find(pp => pp.id === gp.id)!
    ).filter(Boolean);

    startGame(gameState.mode, orderedPlayers, gameState.targetScore);
  };

  const handleScore = (value: number, multiplier: number) => {
    if (!gameState || gameState.isFinished) return;
    initAudio();
    const total = value * multiplier;
    
    let label = total.toString();
    if (total === 180) label = "One Hundred and Eighty!";
    if (total === 0) label = "Miss!";
    speak(label);
    
    setHistory(prev => [...prev.slice(-10), JSON.parse(JSON.stringify(gameState))]);

    const newThrow: Throw = { 
      value, 
      multiplier, 
      total, 
      label: multiplier === 2 ? `D${value}` : multiplier === 3 ? `T${value}` : value === 25 ? (multiplier === 2 ? 'DB' : 'B') : value === 0 ? 'M' : `${value}`, 
      timestamp: Date.now() 
    };
    
    const updatedThrows = [...gameState.currentTurnThrows, newThrow];
    processGameLogic(updatedThrows);
  };

  const processGameLogic = (turn: Throw[]) => {
    if (!gameState) return;
    const player = gameState.players[gameState.currentPlayerIndex];
    const last = turn[turn.length - 1];
    
    if (gameState.mode === GameMode.X01) {
      const newScore = player.score - last.total;
      if (newScore < 0 || newScore === 1) { speak("Bust! No Score."); finishTurn(turn, true); return; }
      if (newScore === 0) {
        if (last.multiplier !== 2) { speak("Must finish on a double!"); finishTurn(turn, true); return; }
        finishGame(player.dartName);
        return;
      }
      updateMidTurn(turn, newScore);
    } else {
      const newScore = player.score + last.total;
      updateMidTurn(turn, newScore);
    }
  };

  const updateMidTurn = (turn: Throw[], newScore: number) => {
    if (!gameState) return;
    const updatedPlayers = gameState.players.map((p, i) => i === gameState.currentPlayerIndex ? { ...p, score: newScore } : p);
    setGameState({ ...gameState, players: updatedPlayers, currentTurnThrows: turn });
    if (turn.length === 3) {
       const sum = turn.reduce((a, b) => a + b.total, 0);
       speak(`Du wirfst ${sum}.`);
       setTimeout(() => finishTurn(turn), 600);
    }
  };

  const finishTurn = (turn: Throw[], isBust: boolean = false) => {
    setGameState(prev => {
      if (!prev) return null;
      const updatedPlayers = prev.players.map((p, i) => i === prev.currentPlayerIndex ? { ...p, history: [...p.history, isBust ? [] : turn] } : p);
      let nextIdx = (prev.currentPlayerIndex + 1) % prev.players.length;
      speak(`Nächster Spieler: ${updatedPlayers[nextIdx].dartName}.`);
      return { ...prev, players: updatedPlayers, currentPlayerIndex: nextIdx, currentTurnThrows: [], round: nextIdx === 0 ? prev.round + 1 : prev.round };
    });
  };

  const finishGame = (winnerName: string) => {
    if (!gameState) return;
    const finalState = { ...gameState, isFinished: true, winner: winnerName };
    setGameState(finalState);
    
    const gameResult: GameResult = {
      id: `g-${Date.now()}`,
      date: new Date().toISOString(),
      mode: gameState.mode,
      players: gameState.players.map(p => {
        const allThrows = [...p.history.flat()];
        const totalPoints = allThrows.reduce((acc, t) => acc + t.total, 0);
        
        const highScores = { sixtyPlus: 0, hundredPlus: 0, hundredFortyPlus: 0, oneEighty: 0 };
        p.history.forEach(turn => {
          const sum = turn.reduce((acc, t) => acc + t.total, 0);
          if (sum === 180) highScores.oneEighty++;
          else if (sum >= 140) highScores.hundredFortyPlus++;
          else if (sum >= 100) highScores.hundredPlus++;
          else if (sum >= 60) highScores.sixtyPlus++;
        });

        return {
          id: p.id,
          name: p.dartName,
          score: p.score,
          totalDarts: allThrows.length,
          totalPoints,
          isWinner: p.dartName === winnerName,
          highScores,
          averagePPD: allThrows.length > 0 ? totalPoints / allThrows.length : 0
        };
      })
    };
    
    const results = JSON.parse(localStorage.getItem('dart_results') || '[]');
    results.push(gameResult);
    localStorage.setItem('dart_results', JSON.stringify(results));
  };

  if (showStats) return <StatsView onClose={() => setShowStats(false)} currentGame={gameState} />;
  if (showPlayerManagement) return <PlayerManagement pool={playerPool} setPool={setPlayerPool} onClose={() => setShowPlayerManagement(false)} />;
  if (showAudioSettings) return <AudioSettings settings={settings} onUpdate={setSettings} onTestVoice={speak} onClose={() => setShowAudioSettings(false)} onGlobalReset={() => { localStorage.clear(); window.location.reload(); }} />;

  if (gameState?.isFinished) {
    return (
      <VictoryScreen 
        gameState={gameState} 
        onRematch={handleRematch} 
        onHome={() => setGameState(null)} 
        speak={speak}
      />
    );
  }

  if (!gameState) return (
    <SetupScreen 
      playerPool={playerPool}
      onStart={startGame} 
      onShowStats={() => setShowStats(true)} 
      onShowAudio={() => setShowAudioSettings(true)}
      onManagePlayers={() => setShowPlayerManagement(true)}
    />
  );

  const activePlayer = gameState.players[gameState.currentPlayerIndex];
  const checkoutPath = gameState.mode === GameMode.X01 ? getDynamicCheckout(activePlayer.score) : null;

  return (
    <div className="flex flex-col h-screen p-3 gap-3 bg-slate-950 text-white overflow-hidden">
      <div className="glass px-6 py-3 rounded-2xl flex justify-between items-center shadow-xl border-indigo-500/10">
        <h1 className="text-xl font-black italic tracking-tighter uppercase">DART MASTER <span className="text-indigo-400">PRO</span></h1>
        <div className="flex gap-2">
           <button onClick={() => setHistory(prev => { 
             if (history.length > 0) {
               const last = history[history.length - 1];
               setGameState(last);
               return prev.slice(0, -1);
             }
             return prev;
           })} disabled={history.length === 0} className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${history.length > 0 ? 'bg-amber-500/20 text-amber-500' : 'bg-slate-800 text-slate-600 opacity-50'}`}>Rückgängig</button>
          <button onClick={() => setShowAudioSettings(true)} className="bg-white/5 hover:bg-white/10 px-4 py-1.5 rounded-lg text-[10px] font-black uppercase border border-white/5">Optionen</button>
          <button onClick={() => setGameState(null)} className="bg-red-500/20 hover:bg-red-500 text-red-500 hover:text-white px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all">Spiel Ende</button>
        </div>
      </div>

      <div className="flex flex-1 gap-3 min-h-0">
        <div className="w-1/4">
          <Scoreboard gameState={gameState} viewMode={settings.scoreboardView} />
        </div>
        <div className="flex-1 bg-slate-900/40 rounded-[2.5rem] border border-white/5 p-4 flex flex-col relative overflow-hidden shadow-2xl">
          
          {/* HUGE CHECKOUT DISPLAY */}
          {checkoutPath && (
            <div className="absolute top-16 left-0 right-0 z-30 pointer-events-none flex flex-col items-center animate-in fade-in slide-in-from-top-4 duration-700">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] mb-3 bg-indigo-950/50 px-4 py-1 rounded-full border border-indigo-500/20">Checkout Empfehlung</p>
              <div className="flex gap-3">
                {checkoutPath.map((dart, i) => {
                  let bgColor = "bg-white/10";
                  let textColor = "text-white";
                  if (dart.startsWith('T')) { bgColor = "bg-red-600 shadow-[0_0_30px_rgba(220,38,38,0.3)]"; textColor = "text-white"; }
                  else if (dart.startsWith('D') || dart === 'Bull') { bgColor = "bg-green-600 shadow-[0_0_30px_rgba(22,163,74,0.4)]"; textColor = "text-white"; }
                  
                  return (
                    <div key={i} className={`w-24 h-24 rounded-[2rem] flex items-center justify-center flex-col border-2 border-white/10 ${bgColor} transition-all animate-bounce`} style={{ animationDelay: `${i * 150}ms`, animationDuration: '2s' }}>
                      <span className={`text-3xl font-black italic tracking-tighter ${textColor}`}>{dart}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex justify-between items-center mb-4 px-4">
            <div className="flex items-center gap-4">
               <img src={getFlagUrl(activePlayer.countryCode)} alt="Current Flag" className="w-16 h-11 rounded-lg shadow-xl object-cover border border-white/10" />
               <div>
                 <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Wurfbereit</p>
                 <h2 className="text-3xl font-black italic tracking-tighter text-white">{activePlayer.dartName}</h2>
               </div>
            </div>
            <div className="flex gap-3">
              {[0, 1, 2].map(i => (
                <div key={i} className={`w-14 h-14 rounded-2xl flex items-center justify-center border-2 transition-all duration-300 ${gameState.currentTurnThrows[i] ? 'bg-indigo-600 border-indigo-400 scale-105 shadow-lg shadow-indigo-500/20' : 'bg-slate-950/80 border-slate-800 opacity-30'}`}>
                  <span className="text-xl font-black">{gameState.currentTurnThrows[i]?.label || ''}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex-1 flex gap-4 min-h-0 items-center justify-center">
            {(settings.inputMode === 'BOARD' || settings.inputMode === 'BOTH') && <div className="flex-1 h-full flex items-center justify-center pt-24"><Dartboard onScore={handleScore} /></div>}
            {(settings.inputMode === 'NUMBERS' || settings.inputMode === 'BOTH') && <div className="w-[340px] pt-24"><NumberInput onScore={handleScore} /></div>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
