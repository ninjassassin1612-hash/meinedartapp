
export enum GameMode {
  X01 = 'X01',
  CRICKET = 'CRICKET',
  AROUND_THE_CLOCK = 'ATC',
  SHANGHAI = 'SHANGHAI',
  HIGH_SCORE = 'HIGHSCORE'
}

export type VoiceProfile = 'MAN' | 'WOMAN' | 'GOAT' | 'EXCITED' | 'CHEEKY';
export type ScoreboardViewMode = 'MASTER' | 'SIMPLIFIED';
export type InputMode = 'BOARD' | 'BOTH' | 'NUMBERS';

export interface PersistentPlayer {
  id: string;
  name: string;
  dartName: string;
  throwingArm: 'Rechts' | 'Links';
  countryCode: string; // Emoji flag or ISO code
  createdAt: number;
  avatarColor: string;
  funnyAnswers: {
    zielwasser: string;
    ausrede: string;
    schrei: string;
    unfall: string;
  };
}

export interface AppSettings {
  voiceProfile: VoiceProfile;
  language: string;
  scoreboardView: ScoreboardViewMode;
  volume: number;
  inputMode: InputMode;
}

export interface Player {
  id: string;
  name: string;
  dartName: string;
  countryCode: string;
  score: number;
  history: Throw[][];
  cricketStats?: Record<number, number>;
  atcNextTarget?: number;
  roundScores?: number[];
}

export interface Throw {
  value: number;
  multiplier: number;
  total: number;
  label: string;
  timestamp: number;
}

export interface GameState {
  mode: GameMode;
  targetScore: number;
  players: Player[];
  currentPlayerIndex: number;
  currentTurnThrows: Throw[];
  isFinished: boolean;
  winner?: string;
  round: number;
  startTime: number;
}

export interface GameResult {
  id: string;
  date: string;
  mode: GameMode;
  players: {
    id: string;
    name: string;
    score: number;
    totalDarts: number;
    totalPoints: number;
    isWinner: boolean;
    highScores: {
      sixtyPlus: number;
      hundredPlus: number;
      hundredFortyPlus: number;
      oneEighty: number;
    };
    averagePPD: number;
  }[];
}
